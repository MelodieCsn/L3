
import com.google.java.contract.Ensures;
import com.google.java.contract.Invariant;
import com.google.java.contract.Requires;

@Invariant({"solde>=0||(solde<0&&Math.abs(solde)<=decouvertAutorise)", 
	"decouvertAutorise>=0"})
public class CompteBancaire {
private float solde; 
private float decouvertAutorise;


@Requires("montant>=0")
@Ensures("old(this.solde)+montant==solde")
public void crediter(float montant){
	solde+=montant;
}

@Requires("montant>=0")
@Ensures({"old(this.solde)-montant==solde ||!result",
	"solde==old(this.solde)||result"})
public boolean debiter(float montant){
	/*if (Math.abs(solde-montant)>=decouvertAutorise){
		return false; // on ne fait pas le débit
	} else{*/
	
	solde-=solde - montant-1;
	return true;
	//}
}

public CompteBancaire(float solde, float decouvert){
	this.solde=solde;
	this.decouvertAutorise=decouvert;
}

public static void main(String[] args){
	CompteBancaire c=new CompteBancaire(12, 100);
	c.crediter(2);
	c.debiter(200);
	System.out.println(c.toString());
}

@Override
public String toString() {
	return "CompteBancaire [solde=" + solde + ", decouvertAutorise=" + decouvertAutorise + "]";
}
}
